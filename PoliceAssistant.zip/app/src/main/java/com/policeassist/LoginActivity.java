package com.policeassist;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private CheckBox cbRemember;

    private TextView tvForgotPassword;
    private TextView tvRegister;

    private MaterialButton btnLogin;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        cbRemember = findViewById(R.id.cbRemember);

        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvRegister = findViewById(R.id.tvRegister);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> loginUser());

        tvForgotPassword.setOnClickListener(v -> resetPassword());

        tvRegister.setOnClickListener(v -> {
            Intent intent = new Intent(
                    LoginActivity.this,
                    ProfileActivity.class
            );
            startActivity(intent);
        });
    }

    private void loginUser() {

        String email = "";

        String password = "";

        if (etUsername.getText() != null) {
            email = etUsername.getText().toString().trim();
        }

        if (etPassword.getText() != null) {
            password = etPassword.getText().toString().trim();
        }

        if (email.isEmpty()) {
            etUsername.setError("Email દાખલ કરો");
            etUsername.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError("Password દાખલ કરો");
            etPassword.requestFocus();
            return;
        }

        btnLogin.setEnabled(false);

        Toast.makeText(
                LoginActivity.this,
                "Login થઈ રહ્યું છે...",
                Toast.LENGTH_SHORT
        ).show();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {

                    btnLogin.setEnabled(true);

                    if (task.isSuccessful()) {

                        Toast.makeText(
                                LoginActivity.this,
                                "Login સફળ થયું",
                                Toast.LENGTH_SHORT
                        ).show();

                        Intent intent = new Intent(
                                LoginActivity.this,
                                MainActivity.class
                        );

                        intent.addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_CLEAR_TASK
                        );

                        startActivity(intent);

                        finish();

                    } else {

                        String errorMessage = "Email અથવા Password ખોટો છે";

                        if (task.getException() != null) {
                            errorMessage =
                                    task.getException().getMessage();
                        }

                        Toast.makeText(
                                LoginActivity.this,
                                errorMessage,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }

    private void resetPassword() {

        String email = "";

        if (etUsername.getText() != null) {
            email = etUsername.getText().toString().trim();
        }

        if (email.isEmpty()) {
            etUsername.setError(
                    "પહેલા Email દાખલ કરો"
            );
            etUsername.requestFocus();
            return;
        }

        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {

                    if (task.isSuccessful()) {

                        Toast.makeText(
                                LoginActivity.this,
                                "Password reset link તમારા Email પર મોકલાઈ છે",
                                Toast.LENGTH_LONG
                        ).show();

                    } else {

                        Toast.makeText(
                                LoginActivity.this,
                                "Password reset થઈ શક્યું નથી",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }
}