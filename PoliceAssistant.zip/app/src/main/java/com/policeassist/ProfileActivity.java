package com.policeassist;

import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class ProfileActivity extends AppCompatActivity {

    private ImageView ivProfilePhoto;

    private MaterialButton btnChoosePhoto;
    private MaterialButton btnSubmitProfile;

    private EditText etName;
    private EditText etDesignation;
    private EditText etBuckleNumber;
    private EditText etPoliceStation;
    private EditText etMobile;
    private EditText etEmail;
    private EditText etUsername;
    private EditText etPassword;

    private Uri selectedPhotoUri;


    // =====================================================
    // PHOTO PICKER
    // =====================================================

    private final ActivityResultLauncher<String> photoPicker =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    uri -> {

                        if (uri != null) {

                            selectedPhotoUri = uri;

                            ivProfilePhoto.setImageURI(uri);

                            Toast.makeText(
                                    ProfileActivity.this,
                                    "ફોટો પસંદ થઈ ગયો",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
            );


    // =====================================================
    // ON CREATE
    // =====================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile);


        // =================================================
        // INITIALIZE VIEWS
        // =================================================

        ivProfilePhoto =
                findViewById(R.id.ivProfilePhoto);

        btnChoosePhoto =
                findViewById(R.id.btnChoosePhoto);

        btnSubmitProfile =
                findViewById(R.id.btnSubmitProfile);

        etName =
                findViewById(R.id.etName);

        etDesignation =
                findViewById(R.id.etDesignation);

        etBuckleNumber =
                findViewById(R.id.etBuckleNumber);

        etPoliceStation =
                findViewById(R.id.etPoliceStation);

        etMobile =
                findViewById(R.id.etMobile);

        etEmail =
                findViewById(R.id.etEmail);

        etUsername =
                findViewById(R.id.etUsername);

        etPassword =
                findViewById(R.id.etPassword);


        // =================================================
        // CHOOSE PHOTO
        // =================================================

        btnChoosePhoto.setOnClickListener(v -> {

            photoPicker.launch("image/*");

        });


        // =================================================
        // SUBMIT PROFILE
        // =================================================

        btnSubmitProfile.setOnClickListener(v -> {

            submitProfile();

        });

    }


    // =====================================================
    // SUBMIT PROFILE
    // =====================================================

    private void submitProfile() {

        String name =
                getText(etName);

        String designation =
                getText(etDesignation);

        String buckleNumber =
                getText(etBuckleNumber);

        String policeStation =
                getText(etPoliceStation);

        String mobile =
                getText(etMobile);

        String email =
                getText(etEmail);

        String username =
                getText(etUsername);

        String password =
                getText(etPassword);


        // =================================================
        // NAME
        // =================================================

        if (name.isEmpty()) {

            etName.setError(
                    "કર્મચારીનું નામ દાખલ કરો"
            );

            etName.requestFocus();

            return;
        }


        // =================================================
        // DESIGNATION
        // =================================================

        if (designation.isEmpty()) {

            etDesignation.setError(
                    "હોદ્દો દાખલ કરો"
            );

            etDesignation.requestFocus();

            return;
        }


        // =================================================
        // BUCKLE NUMBER
        // =================================================

        if (buckleNumber.isEmpty()) {

            etBuckleNumber.setError(
                    "બકલ નંબર દાખલ કરો"
            );

            etBuckleNumber.requestFocus();

            return;
        }


        // =================================================
        // POLICE STATION
        // =================================================

        if (policeStation.isEmpty()) {

            etPoliceStation.setError(
                    "પોલીસ સ્ટેશન દાખલ કરો"
            );

            etPoliceStation.requestFocus();

            return;
        }


        // =================================================
        // MOBILE
        // =================================================

        if (mobile.isEmpty()) {

            etMobile.setError(
                    "મોબાઇલ નંબર દાખલ કરો"
            );

            etMobile.requestFocus();

            return;
        }

        if (mobile.length() != 10) {

            etMobile.setError(
                    "10 અંકનો મોબાઇલ નંબર દાખલ કરો"
            );

            etMobile.requestFocus();

            return;
        }


        // =================================================
        // EMAIL
        // =================================================

        if (email.isEmpty()) {

            etEmail.setError(
                    "Email દાખલ કરો"
            );

            etEmail.requestFocus();

            return;
        }


        // =================================================
        // USERNAME
        // =================================================

        if (username.isEmpty()) {

            etUsername.setError(
                    "Username દાખલ કરો"
            );

            etUsername.requestFocus();

            return;
        }


        // =================================================
        // PASSWORD
        // =================================================

        if (password.isEmpty()) {

            etPassword.setError(
                    "Password દાખલ કરો"
            );

            etPassword.requestFocus();

            return;
        }

        if (password.length() < 6) {

            etPassword.setError(
                    "Password ઓછામાં ઓછો 6 અક્ષરનો હોવો જોઈએ"
            );

            etPassword.requestFocus();

            return;
        }


        // =================================================
        // PHOTO
        // =================================================

        if (selectedPhotoUri == null) {

            Toast.makeText(
                    this,
                    "કૃપા કરીને Profile Photo પસંદ કરો",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // =================================================
        // TEMPORARY SUCCESS
        // =================================================

        Toast.makeText(
                this,
                "Profile તૈયાર છે. Firebase Approval પછી જોડશું.",
                Toast.LENGTH_LONG
        ).show();

    }


    // =====================================================
    // GET TEXT
    // =====================================================

    private String getText(EditText editText) {

        if (editText.getText() == null) {
            return "";
        }

        return editText.getText()
                .toString()
                .trim();
    }

}